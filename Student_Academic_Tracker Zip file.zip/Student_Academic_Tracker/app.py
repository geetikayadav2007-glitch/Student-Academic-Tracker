
import sqlite3
from pathlib import Path

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import database as db


# --------------------------------------------------
# PAGE CONFIGURATION
# --------------------------------------------------
st.set_page_config(
    page_title="Student Academic Tracker",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Safe initialization: creates missing tables only.
# Existing database records are not deleted.
db.initialize_database()


# --------------------------------------------------
# DARK THEME DESIGN
# --------------------------------------------------
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

.stApp {
    background: linear-gradient(135deg, #080d19 0%, #10172a 100%);
    color: #f1f5f9;
    font-family: 'Inter', sans-serif;
}

[data-testid="stSidebar"] {
    background: #0b1120;
    border-right: 1px solid #26334b;
}

[data-testid="stHeader"] {
    background: transparent;
}

.block-container {
    max-width: 1500px;
    padding-top: 2rem;
    padding-bottom: 3rem;
}

h1, h2, h3 {
    color: #f8fafc !important;
    font-weight: 750 !important;
}

p, label, span {
    color: #cbd5e1;
}

div[data-testid="stMetric"] {
    background: linear-gradient(145deg, #18243a, #111a2d);
    border: 1px solid #30415d;
    border-radius: 16px;
    padding: 20px 18px;
    box-shadow: 0 8px 24px rgba(0,0,0,.15);
}

div[data-testid="stMetricLabel"] {
    color: #a5b4fc !important;
}

div[data-testid="stMetricValue"] {
    color: #67e8f9 !important;
    font-weight: 800;
}

div[data-testid="stForm"] {
    background: #111b2d;
    border: 1px solid #30415d;
    border-radius: 16px;
    padding: 20px;
}

.stButton > button,
.stFormSubmitButton > button {
    background: linear-gradient(90deg, #6366f1, #8b5cf6);
    color: white;
    border: none;
    border-radius: 10px;
    font-weight: 700;
    min-height: 42px;
}

.stButton > button:hover,
.stFormSubmitButton > button:hover {
    border: 1px solid #a5b4fc;
    color: white;
}

div[data-baseweb="input"] input,
div[data-baseweb="select"] > div,
div[data-baseweb="textarea"] textarea {
    background-color: #172238;
    color: white;
}

[data-testid="stDataFrame"] {
    border: 1px solid #30415d;
    border-radius: 12px;
}

hr {
    border-color: #29364e;
}

.hero {
    padding: 25px 28px;
    background: linear-gradient(120deg, #172554, #312e81, #164e63);
    border: 1px solid #3b4d79;
    border-radius: 20px;
    margin-bottom: 25px;
}

.hero p {
    color: #dbeafe;
    margin-bottom: 0;
}

.section-note {
    color: #94a3b8;
    font-size: 14px;
}

</style>
""", unsafe_allow_html=True)


# --------------------------------------------------
# HELPER FUNCTIONS
# --------------------------------------------------
def load_data():
    students = pd.DataFrame(db.get_students())
    attendance = pd.DataFrame(db.get_attendance())
    marks = pd.DataFrame(db.get_marks())
    return students, attendance, marks


def student_label(student):
    return (
        f"{student['name']} | "
        f"{student['roll_number']} | ID: {student['id']}"
    )


def student_selector(students, key):
    if students.empty:
        st.warning("Pehle Students section mein student add karo.")
        return None

    options = students.to_dict("records")
    labels = {student_label(s): s["id"] for s in options}

    selected = st.selectbox(
        "Select Student",
        list(labels.keys()),
        key=key
    )
    return labels[selected]


def show_error(error):
    st.error(f"Error: {error}")


def download_csv(dataframe, filename, label):
    csv = dataframe.to_csv(index=False).encode("utf-8-sig")
    st.download_button(
        label=label,
        data=csv,
        file_name=filename,
        mime="text/csv",
        use_container_width=True
    )


def make_chart_dark(fig, height=360):
    fig.update_layout(
        height=height,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#dbeafe", family="Inter"),
        margin=dict(l=15, r=15, t=45, b=20),
        legend=dict(
            bgcolor="rgba(0,0,0,0)",
            font=dict(color="#cbd5e1")
        ),
        title_font=dict(size=18, color="#f8fafc"),
    )
    fig.update_xaxes(
        gridcolor="#25334a",
        linecolor="#334155",
        zerolinecolor="#334155"
    )
    fig.update_yaxes(
        gridcolor="#25334a",
        linecolor="#334155",
        zerolinecolor="#334155"
    )
    return fig


# --------------------------------------------------
# SIDEBAR NAVIGATION
# --------------------------------------------------
with st.sidebar:
    st.markdown("# 🎓 SAT")
    st.caption("STUDENT ACADEMIC TRACKER")
    st.divider()

    page = st.radio(
        "NAVIGATION",
        [
            "🏠 Dashboard",
            "👨‍🎓 Students",
            "📅 Attendance",
            "📊 Marks & Grades",
            "📥 Reports & Export",
        ],
        label_visibility="visible"
    )

    st.divider()
    st.caption("DATABASE")
    st.code(str(db.DB_PATH), language=None)

    if st.button("🔄 Refresh Data", use_container_width=True):
        st.rerun()


students, attendance, marks = load_data()

# --------------------------------------------------
# DASHBOARD
# --------------------------------------------------
if page == "🏠 Dashboard":

    st.markdown("""
    <div class="hero">
        <h1>🎓 Student Academic Tracker</h1>
        <p>Your academic performance, organized in one place.</p>
    </div>
    """, unsafe_allow_html=True)

    stats = db.get_dashboard_stats()

    st.subheader("📌 Performance Overview")

    c1, c2, c3, c4 = st.columns(4)

    c1.metric("👨‍🎓 Total Students", stats["total_students"])
    c2.metric("📝 Marks Records", stats["total_marks_records"])
    c3.metric(
        "📅 Attendance",
        f"{stats['attendance_percentage']:.1f}%"
    )
    c4.metric(
        "🎯 Average Marks",
        f"{stats['average_marks_percentage']:.1f}%"
    )

    st.divider()

    left, right = st.columns(2)

    with left:
        st.subheader("📊 Subject-wise Performance")

        if not marks.empty:
            subject_scores = (
                marks.groupby("subject", as_index=False)["percentage"]
                .mean()
                .sort_values("percentage", ascending=False)
            )

            fig = px.bar(
                subject_scores,
                x="subject",
                y="percentage",
                color="percentage",
                color_continuous_scale=["#818cf8", "#22d3ee", "#34d399"],
                text_auto=".1f",
                title="Average score by subject"
            )
            fig.update_traces(
                textposition="outside",
                cliponaxis=False
            )
            fig.update_yaxes(title="Average score (%)", range=[0, 110])
            fig.update_xaxes(title="")
            fig.update_layout(coloraxis_showscale=False)
            st.plotly_chart(
                make_chart_dark(fig, 400),
                use_container_width=True
            )
        else:
            st.info("Chart dekhne ke liye marks records add karo.")

    with right:
        st.subheader("🍩 Attendance Overview")

        if not attendance.empty:
            total_classes = int(attendance["total_classes"].sum())
            attended = int(attendance["attended_classes"].sum())
            missed = max(total_classes - attended, 0)

            if total_classes > 0:
                fig = go.Figure(data=[go.Pie(
                    labels=["Attended", "Missed"],
                    values=[attended, missed],
                    hole=0.68,
                    marker=dict(colors=["#34d399", "#fb7185"]),
                    textinfo="label+percent",
                    textfont=dict(color="white", size=13)
                )])
                fig.update_layout(
                    title="Classes attended vs missed",
                    showlegend=True
                )
                st.plotly_chart(
                    make_chart_dark(fig, 400),
                    use_container_width=True
                )
            else:
                st.info("Attendance classes abhi zero hain.")
        else:
            st.info("Attendance records add karne ke baad chart dikhega.")

    st.divider()

    st.subheader("🏆 Recent Marks Records")
    if not marks.empty:
        columns = [
            "name", "roll_number", "subject", "assessment",
            "obtained_marks", "maximum_marks", "percentage"
        ]
        recent = marks[columns].head(8).copy()
        recent.columns = [
            "Student", "Roll Number", "Subject", "Assessment",
            "Obtained", "Maximum", "Percentage"
        ]
        st.dataframe(recent, hide_index=True, use_container_width=True)
    else:
        st.info("Abhi koi marks record available nahi hai.")

    st.subheader("📅 Attendance by Subject")
    if not attendance.empty:
        subject_attendance = attendance.groupby(
            "subject", as_index=False
        ).agg(
            attended_classes=("attended_classes", "sum"),
            total_classes=("total_classes", "sum")
        )

        subject_attendance["Attendance %"] = (
            100 * subject_attendance["attended_classes"]
            / subject_attendance["total_classes"].replace(0, float("nan"))
        ).fillna(0).round(2)

        fig = px.bar(
            subject_attendance,
            x="subject",
            y="Attendance %",
            color="Attendance %",
            color_continuous_scale=["#fb7185", "#fbbf24", "#34d399"],
            range_y=[0, 110],
            title="Attendance percentage by subject"
        )
        fig.update_layout(coloraxis_showscale=False)
        st.plotly_chart(
            make_chart_dark(fig, 350),
            use_container_width=True
        )
    else:
        st.info("Attendance records available nahi hain.")


# --------------------------------------------------
# STUDENTS PAGE
# --------------------------------------------------
elif page == "👨‍🎓 Students":

    st.title("👨‍🎓 Student Management")
    st.caption("Add students and view saved student records.")

    with st.expander("➕ Add New Student", expanded=False):
        with st.form("add_student_form", clear_on_submit=True):
            name = st.text_input("Full Name")
            roll = st.text_input("Roll Number")
            course = st.text_input(
                "Course", value="B.Tech CSE AIML"
            )
            semester = st.number_input(
                "Semester", min_value=1, max_value=12, value=3
            )
            email = st.text_input("Email (optional)")

            submitted = st.form_submit_button(
                "Save Student", use_container_width=True
            )

            if submitted:
                if not name.strip() or not roll.strip():
                    st.error("Name aur roll number required hain.")
                else:
                    try:
                        db.add_student(
                            name, roll, course, semester, email
                        )
                        st.success("Student successfully saved!")
                        st.rerun()
                    except sqlite3.IntegrityError:
                        st.error(
                            "Ye roll number already exist karta hai."
                        )
                    except Exception as e:
                        show_error(e)

    st.subheader(f"Registered Students ({len(students)})")

    if not students.empty:
        search = st.text_input(
            "🔎 Search by name or roll number"
        )

        filtered = students.copy()
        if search.strip():
            mask = (
                filtered["name"].astype(str).str.contains(
                    search, case=False, na=False
                )
                | filtered["roll_number"].astype(str).str.contains(
                    search, case=False, na=False
                )
            )
            filtered = filtered[mask]

        st.dataframe(
            filtered,
            hide_index=True,
            use_container_width=True
        )
        download_csv(
            filtered,
            "students.csv",
            "⬇️ Download Students CSV"
        )
    else:
        st.info("Abhi koi student registered nahi hai.")


# --------------------------------------------------
# ATTENDANCE PAGE
# --------------------------------------------------
elif page == "📅 Attendance":

    st.title("📅 Attendance Management")
    st.caption("Record and review student attendance.")

    tab1, tab2 = st.tabs(
        ["➕ Record Attendance", "📋 Attendance Records"]
    )

    with tab1:
        with st.form("attendance_form", clear_on_submit=True):
            student_id = student_selector(
                students, "attendance_student"
            )

            subject = st.text_input("Subject")
            total = st.number_input(
                "Total Classes", min_value=0, value=30, step=1
            )
            attended = st.number_input(
                "Classes Attended", min_value=0, value=25, step=1
            )

            submitted = st.form_submit_button(
                "💾 Save Attendance", use_container_width=True
            )

            if submitted:
                if student_id is None:
                    st.error("Pehle student add karo.")
                elif not subject.strip():
                    st.error("Subject ka naam required hai.")
                elif attended > total:
                    st.error(
                        "Attended classes, total classes se zyada nahi ho sakti."
                    )
                else:
                    try:
                        db.add_attendance(
                            student_id, subject, total, attended
                        )
                        st.success("Attendance saved successfully!")
                        st.rerun()
                    except Exception as e:
                        show_error(e)

    with tab2:
        if not attendance.empty:
            st.dataframe(
                attendance,
                hide_index=True,
                use_container_width=True
            )
            download_csv(
                attendance,
                "attendance.csv",
                "⬇️ Download Attendance CSV"
            )
        else:
            st.info("Attendance records abhi available nahi hain.")


# --------------------------------------------------
# MARKS PAGE
# --------------------------------------------------
elif page == "📊 Marks & Grades":

    st.title("📊 Marks & Grades")
    st.caption("Save assessment results and analyze performance.")

    tab1, tab2 = st.tabs(
        ["➕ Add Marks", "📋 Marks Records"]
    )

    with tab1:
        with st.form("marks_form", clear_on_submit=True):
            student_id = student_selector(students, "marks_student")
            subject = st.text_input("Subject")
            assessment = st.selectbox(
                "Assessment",
                [
                    "Assignment", "Quiz", "Project",
                    "Mid-Term", "End-Term", "Practical", "Other"
                ]
            )
            maximum = st.number_input(
                "Maximum Marks",
                min_value=1.0, max_value=10000.0, value=100.0
            )
            obtained = st.number_input(
                "Obtained Marks",
                min_value=0.0, max_value=10000.0, value=80.0
            )

            submitted = st.form_submit_button(
                "💾 Save Marks", use_container_width=True
            )

            if submitted:
                if student_id is None:
                    st.error("Pehle student add karo.")
                elif not subject.strip():
                    st.error("Subject ka naam required hai.")
                elif maximum <= 0 or obtained > maximum:
                    st.error(
                        "Obtained marks maximum marks ke andar hone chahiye."
                    )
                else:
                    try:
                        db.add_marks(
                            student_id, subject, assessment,
                            obtained, maximum
                        )
                        st.success("Marks saved successfully!")
                        st.rerun()
                    except Exception as e:
                        show_error(e)

    with tab2:
        if not marks.empty:
            st.dataframe(
                marks,
                hide_index=True,
                use_container_width=True
            )

            st.subheader("📈 Marks Distribution")
            fig = px.histogram(
                marks,
                x="percentage",
                nbins=10,
                color_discrete_sequence=["#818cf8"],
                title="Distribution of assessment percentages"
            )
            fig.update_xaxes(title="Percentage (%)")
            fig.update_yaxes(title="Number of records")
            st.plotly_chart(
                make_chart_dark(fig, 350),
                use_container_width=True
            )

            download_csv(
                marks,
                "marks.csv",
                "⬇️ Download Marks CSV"
            )
        else:
            st.info("Marks records abhi available nahi hain.")


# --------------------------------------------------
# REPORTS AND EXPORT PAGE
# --------------------------------------------------
elif page == "📥 Reports & Export":

    st.title("📥 Reports & Export")
    st.caption("Download your existing academic records as CSV files.")

    st.subheader("📊 Database Summary")
    stats = db.get_dashboard_stats()

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Students", stats["total_students"])
    c2.metric("Marks Records", stats["total_marks_records"])
    c3.metric(
        "Attendance",
        f"{stats['attendance_percentage']:.2f}%"
    )
    c4.metric(
        "Average Marks",
        f"{stats['average_marks_percentage']:.2f}%"
    )

    st.divider()

    st.subheader("⬇️ Export Data")

    col1, col2, col3 = st.columns(3)

    with col1:
        st.markdown("### 👨‍🎓 Students")
        st.caption("All registered student records.")
        download_csv(
            students, "students.csv", "Download Students"
        )

    with col2:
        st.markdown("### 📅 Attendance")
        st.caption("Attendance records and percentages.")
        download_csv(
            attendance, "attendance.csv", "Download Attendance"
        )

    with col3:
        st.markdown("### 📊 Marks")
        st.caption("Assessment results and percentages.")
        download_csv(
            marks, "marks.csv", "Download Marks"
        )

    st.divider()

    st.subheader("🗄️ Database Information")
    st.write("Database file location:")
    st.code(str(db.DB_PATH), language=None)
    st.write("Available tables:")
    st.write(", ".join(db.get_table_names()))

    st.info(
        "This dashboard does not delete or reset existing records. "
        "CSV downloads are copies of the displayed data."
    )
