
import streamlit as st

st.set_page_config(page_title="Student Academic Tracker")

st.title("🎓 Student Academic Tracker")
st.success("Application is working!")
st.write("Python and Streamlit are running successfully.")
