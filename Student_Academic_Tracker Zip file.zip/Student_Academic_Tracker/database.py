
import sqlite3
from pathlib import Path
from contextlib import contextmanager

# Use the same folder as this database.py file
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "academic_tracker.db"


@contextmanager
def get_connection():
    """Open and safely close a database connection."""
    conn = sqlite3.connect(str(DB_PATH), timeout=10)
    conn.row_factory = sqlite3.Row

    try:
        conn.execute("PRAGMA foreign_keys = ON")
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def get_table_names():
    """Return all existing user-created table names."""
    with get_connection() as conn:
        rows = conn.execute("""
            SELECT name
            FROM sqlite_master
            WHERE type = 'table'
              AND name NOT LIKE 'sqlite_%'
            ORDER BY name
        """).fetchall()

    return [row["name"] for row in rows]


def initialize_database():
    """
    Create missing tables without deleting existing records.
    Existing tables are left untouched.
    """
    with get_connection() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                roll_number TEXT NOT NULL UNIQUE,
                course TEXT NOT NULL DEFAULT 'B.Tech CSE AIML',
                semester INTEGER NOT NULL DEFAULT 3,
                email TEXT DEFAULT '',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS attendance (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id INTEGER NOT NULL,
                subject TEXT NOT NULL,
                total_classes INTEGER NOT NULL DEFAULT 0,
                attended_classes INTEGER NOT NULL DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (student_id)
                    REFERENCES students(id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS marks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id INTEGER NOT NULL,
                subject TEXT NOT NULL,
                assessment TEXT NOT NULL DEFAULT 'Assignment',
                obtained_marks REAL NOT NULL DEFAULT 0,
                maximum_marks REAL NOT NULL DEFAULT 100,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (student_id)
                    REFERENCES students(id) ON DELETE CASCADE
            );

            CREATE INDEX IF NOT EXISTS idx_attendance_student
                ON attendance(student_id);

            CREATE INDEX IF NOT EXISTS idx_marks_student
                ON marks(student_id);
        """)


def add_student(name, roll_number, course="B.Tech CSE AIML",
                semester=3, email=""):
    """Add a student without duplicating a roll number."""
    with get_connection() as conn:
        cursor = conn.execute("""
            INSERT INTO students
                (name, roll_number, course, semester, email)
            VALUES (?, ?, ?, ?, ?)
        """, (name.strip(), roll_number.strip(), course,
              int(semester), email.strip()))

        return cursor.lastrowid


def get_students():
    """Get all students."""
    with get_connection() as conn:
        rows = conn.execute("""
            SELECT * FROM students ORDER BY id
        """).fetchall()

    return [dict(row) for row in rows]


def get_student_by_id(student_id):
    with get_connection() as conn:
        row = conn.execute(
            "SELECT * FROM students WHERE id = ?",
            (student_id,)
        ).fetchone()

    return dict(row) if row else None


def add_attendance(student_id, subject, total_classes,
                   attended_classes):
    total_classes = int(total_classes)
    attended_classes = int(attended_classes)

    if total_classes < 0:
        raise ValueError("Total classes cannot be negative.")

    if not 0 <= attended_classes <= total_classes:
        raise ValueError(
            "Attended classes must be between 0 and total classes."
        )

    with get_connection() as conn:
        conn.execute("""
            INSERT INTO attendance
                (student_id, subject, total_classes, attended_classes)
            VALUES (?, ?, ?, ?)
        """, (student_id, subject.strip(),
              total_classes, attended_classes))


def get_attendance(student_id=None):
    query = """
        SELECT a.*, s.name, s.roll_number,
               CASE
                   WHEN a.total_classes > 0
                   THEN ROUND(
                       100.0 * a.attended_classes / a.total_classes, 2
                   )
                   ELSE 0
               END AS attendance_percentage
        FROM attendance a
        JOIN students s ON s.id = a.student_id
    """

    params = ()
    if student_id is not None:
        query += " WHERE a.student_id = ?"
        params = (student_id,)

    query += " ORDER BY a.id DESC"

    with get_connection() as conn:
        rows = conn.execute(query, params).fetchall()

    return [dict(row) for row in rows]


def add_marks(student_id, subject, assessment,
              obtained_marks, maximum_marks=100):
    obtained_marks = float(obtained_marks)
    maximum_marks = float(maximum_marks)

    if maximum_marks <= 0:
        raise ValueError("Maximum marks must be greater than zero.")

    if not 0 <= obtained_marks <= maximum_marks:
        raise ValueError(
            "Obtained marks must be between zero and maximum marks."
        )

    with get_connection() as conn:
        conn.execute("""
            INSERT INTO marks
                (student_id, subject, assessment,
                 obtained_marks, maximum_marks)
            VALUES (?, ?, ?, ?, ?)
        """, (student_id, subject.strip(), assessment.strip(),
              obtained_marks, maximum_marks))


def get_marks(student_id=None):
    query = """
        SELECT m.*, s.name, s.roll_number,
               ROUND(
                   100.0 * m.obtained_marks / m.maximum_marks, 2
               ) AS percentage
        FROM marks m
        JOIN students s ON s.id = m.student_id
    """

    params = ()
    if student_id is not None:
        query += " WHERE m.student_id = ?"
        params = (student_id,)

    query += " ORDER BY m.id DESC"

    with get_connection() as conn:
        rows = conn.execute(query, params).fetchall()

    return [dict(row) for row in rows]


def get_dashboard_stats():
    """Return summary statistics for the dashboard."""
    with get_connection() as conn:
        student_count = conn.execute(
            "SELECT COUNT(*) FROM students"
        ).fetchone()[0]

        marks_count = conn.execute(
            "SELECT COUNT(*) FROM marks"
        ).fetchone()[0]

        attendance = conn.execute("""
            SELECT COALESCE(SUM(attended_classes), 0),
                   COALESCE(SUM(total_classes), 0)
            FROM attendance
        """).fetchone()

        average_marks = conn.execute("""
            SELECT AVG(100.0 * obtained_marks / maximum_marks)
            FROM marks
        """).fetchone()[0]

    attended, total = attendance

    return {
        "total_students": student_count,
        "total_marks_records": marks_count,
        "attendance_percentage": round(
            100 * attended / total, 2
        ) if total else 0,
        "average_marks_percentage": round(
            average_marks, 2
        ) if average_marks is not None else 0
    }


def initialize_and_check():
    """Initialize missing tables and print the database location."""
    initialize_database()

    print("Database path:", DB_PATH)
    print("Available tables:", get_table_names())
    print("Students found:", len(get_students()))
    print("Dashboard statistics:", get_dashboard_stats())


if __name__ == "__main__":
    initialize_and_check()
